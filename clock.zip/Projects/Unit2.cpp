//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"




//---------------------------------------------------------------------------
#pragma link "cspin"
#pragma resource "*.dfm"
TForm2 *Form2;




//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm2::Button2Click(TObject *Sender)
{
  Form2->Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm2::Button1Click(TObject *Sender)
{
	Form2->Close();
	k++;
	input[k].id = CSpinEdit3->Value;
	input[k].hour=CSpinEdit1->Value;
	input[k].min=CSpinEdit2->Value;
	input[k].sound=ComboBox1->ItemIndex;

	ofstream out(PATH,ios::app);
	out << ' ' << input[k].id << ' ' <<input[k].hour << ' ' << input[k].min << ' '<< input[k].sound;
	out.close();

	TLabel *a_name =  new TLabel(Form1->GridPanel1);
	a_name->Caption = "Alarm" + IntToStr(input[k].id) + "  " + input[k].hour + ":" + input[k].min;
	a_name->Parent=Form1->GridPanel1;


	TButton *off= new TButton(Form1->GridPanel1);
	off->HelpContext=k;
	off->Caption = "�������";
	off->OnClick = offClick;
	off->Parent = Form1->GridPanel1;

	TTimer* a_time = new TTimer(Form1->GridPanel1);
	if (input[k].sound==0)
	{
	a_time->OnTimer = ring1;
	}
	else
	{
	a_time->OnTimer = ring2;
	}


	time(&t);
	area = localtime(&t);
	r_h= area->tm_hour;
	r_m= area->tm_min;

	if (input[k].hour > r_h || (input[k].hour==r_h && input[k].min > r_m))
	{
		a_time->Interval=(input[k].hour-r_h)*3600000 + (input[k].min-r_m)*60000 ;
	}
	else
	{
		if (r_m>input[k].min)
		{
			a_time->Interval= 24*3600000 -(r_h-input[k].hour)*3600000 - (r_m-input[k].min)*60000;
		}
		else
		{
			a_time->Interval= 24*3600000 - (r_h-input[k].hour)*3600000 - (input[k].min-r_m)*60000;
		}
	}
	a_time->Enabled=true;

}
//---------------------------------------------------------------------------
  void __fastcall TForm2::offClick(TObject *Sender)
{
	Form1->GridPanel1->DestroyComponents();
	TButton *offc = dynamic_cast<TButton*>(Sender);
	n=offc->HelpContext;
	for (n; n<k ;n++)
	{
		input[n] = input[n+1];
	}
	k--;

	ofstream reout(PATH,ios::out);
	for (int i=0; i<=k; i++)
	{
		reout << ' ' << input[k].id << ' ' <<input[k].hour << ' ' << input[k].min << ' '<< input[k].sound;
	}
	reout.close();

	for (int i=0; i<=k; i++)
	{
		TLabel *a_name =  new TLabel(Form1->GridPanel1);
		a_name->Caption = "Alarm" + IntToStr(input[k].id) + "  " + input[k].hour + ":" + input[k].min;
		a_name->Parent=Form1->GridPanel1;


		TButton *off= new TButton(Form1->GridPanel1);
		off->HelpContext=k;
		off->Caption = "�������";
		off->OnClick = offClick;
		off->Parent = Form1->GridPanel1;

		TTimer* a_time = new TTimer(Form1->GridPanel1);
		if (input[k].sound==0)
		{
		a_time->OnTimer = ring1;
		}
		else
		{
		a_time->OnTimer = ring2;
		}


		time(&t);
		area = localtime(&t);
		r_h= area->tm_hour;
		r_m= area->tm_min;

		if (input[k].hour > r_h || (input[k].hour==r_h && input[k].min > r_m))
		{
			a_time->Interval=(input[k].hour-r_h)*3600000 + (input[k].min-r_m)*60000 ;
		}
		else
		{
			if (r_m>input[k].min)
			{
				a_time->Interval= 24*3600000 -(r_h-input[k].hour)*3600000 - (r_m-input[k].min)*60000;
			}
			else
			{
				a_time->Interval= 24*3600000 -(r_h-input[k].hour)*3600000 - (input[k].min-r_m)*60000;
			}
		}
		a_time->Enabled=true;
	}



}
//---------------------------------------------------------------------------
  void __fastcall TForm2::ring1(TObject *Sender)
{
	TTimer *off_t1 = dynamic_cast<TTimer*>(Sender);
	PlaySoundA("C:\\Users\\�DMN\\source\\bud.wav", NULL, SND_ASYNC);
	ShowMessage("��������� �����������");
	off_t1->Enabled=false;

}
//---------------------------------------------------------------------------
  void __fastcall TForm2::ring2(TObject *Sender)
{
	TTimer *off_t2 = dynamic_cast<TTimer*>(Sender);
	PlaySoundA("C:\\Users\\�DMN\\source\\bud2.wav", NULL, SND_ASYNC);
	ShowMessage("��������� �����������");
	off_t2->Enabled=false;

}
//---------------------------------------------------------------------------
void __fastcall TForm2::FormCreate(TObject *Sender)
{
	ComboBox1->Text = "�������� �������";
	ComboBox1->Items->Add("�������1");
	ComboBox1->Items->Add("�������2");
}
//---------------------------------------------------------------------------


