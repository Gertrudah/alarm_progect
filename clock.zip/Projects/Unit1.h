//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Menus.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TButton *Button1;
	TGridPanel *GridPanel1;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------



#include <ctime>
#include <fstream>
#include <cstdio>
#include <mmsystem.h>
using namespace std;




int k=0;
int n;

struct alarm_clock {
    int id;
	int hour,min;
	int sound;
};

alarm_clock input[10];

int r_h,r_m;
time_t t;
tm *area;

const char* PATH = "C:\\Users\\�DMN\\source\\alarf.txt";

#endif

