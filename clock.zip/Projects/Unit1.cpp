//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"

//---------------------------------------------------------------------------

#pragma resource "*.dfm"


TForm1 *Form1;




//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  if (k<10)
  {
	Form2->Show();
  }
   else
  {
	ShowMessage("��������� ���������� �����������");
  }


}
//---------------------------------------------------------------------------






void __fastcall TForm1::FormCreate(TObject *Sender)
{
  ifstream in(PATH,ios::in);

  if (!in.is_open())
  {
  return ;
  }

  k = 0;
  while(!in.eof())
  {
	  in >> input[k].id >>input[k].hour >> input[k].min >> input[k].sound;

	  TLabel *a_name =  new TLabel(GridPanel1);
	  a_name->Caption = "Alarm" + IntToStr(input[k].id) + "  " + input[k].hour + ":" + input[k].min;
	  a_name->Parent=GridPanel1;


	  TButton *off= new TButton(GridPanel1);
      off->HelpContext=k;
	  off->Caption = "�������";
	  off->OnClick =Form2->offClick ;
	  off->Parent = GridPanel1;

	  TTimer *a_time = new TTimer(GridPanel1);
	  if (input[k].sound==0)
		{
		a_time->OnTimer = Form2->ring1;
		}
		else
		{
		a_time->OnTimer = Form2->ring2;
		}

	  time(&t);
	  area = localtime(&t);
	  r_h= area->tm_hour;
	  r_m= area->tm_min;

	  if (input[k].hour > r_h || (input[k].hour==r_h && input[k].min > r_m))
	  {
		  a_time->Interval=(input[k].hour-r_h)*3600000 + (input[k].min-r_m)*60000 ;
	  }
	  else
	  {
		if (r_m>input[k].min)
		  {
			a_time->Interval=24*3600000 - (r_h-input[k].hour)*3600000 - (r_m-input[k].min)*60000;
		  }
		else
		{
			a_time->Interval= 24*3600000 -(r_h-input[k].hour)*3600000 - (input[k].min-r_m)*60000;
		}
	  }
	  a_time->Enabled=true;
	  k++;
  }
	  in.close();
}
//---------------------------------------------------------------------------




